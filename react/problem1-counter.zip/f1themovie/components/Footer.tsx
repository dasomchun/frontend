import React from 'react';
import { Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-zinc-900 py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        
        <div className="text-center md:text-left">
          <h2 className="text-2xl font-black text-white tracking-tighter mb-2 italic">F1: THE MOVIE</h2>
          <p className="text-zinc-500 text-xs tracking-widest uppercase">
            © 2024 Apex Productions. All Rights Reserved.
          </p>
          <p className="text-zinc-600 text-[11px] mt-2 max-w-sm leading-relaxed keep-all">
            이것은 포트폴리오 프로젝트입니다. Formula 1, FIA 또는 어떠한 레이싱 팀과도 공식적인 관련이 없습니다. 열정적인 엔지니어가 기획 및 개발했습니다.
          </p>
        </div>

        <div className="flex gap-6">
          <a href="#" className="text-zinc-400 hover:text-f1-red transition-colors transform hover:scale-110">
            <Facebook size={20} />
          </a>
          <a href="#" className="text-zinc-400 hover:text-f1-red transition-colors transform hover:scale-110">
            <Twitter size={20} />
          </a>
          <a href="#" className="text-zinc-400 hover:text-f1-red transition-colors transform hover:scale-110">
            <Instagram size={20} />
          </a>
          <a href="#" className="text-zinc-400 hover:text-f1-red transition-colors transform hover:scale-110">
            <Youtube size={20} />
          </a>
        </div>

        <div className="text-center md:text-right">
          <div className="flex flex-col gap-1">
             <span className="text-zinc-500 text-xs uppercase tracking-widest">감독</span>
             <span className="text-white text-sm font-bold uppercase">크리스토퍼 놀란</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;