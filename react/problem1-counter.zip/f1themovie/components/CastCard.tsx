import React from 'react';
import { motion } from 'framer-motion';
import { CastMember } from '../types';

const CastCard: React.FC<{ member: CastMember }> = ({ member }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="group relative overflow-hidden h-[500px] cursor-pointer"
    >
      <img 
        src={member.image} 
        alt={member.name} 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:grayscale-0 grayscale" 
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
      
      <div className="absolute bottom-0 left-0 w-full p-6 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
        <p className="text-f1-red font-bold uppercase tracking-widest text-xs mb-1">{member.role}</p>
        <h3 className="text-3xl font-black italic text-white mb-2 uppercase">{member.name}</h3>
        <div className="h-0 group-hover:h-auto overflow-hidden transition-all duration-500">
           <p className="text-zinc-400 text-sm mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-700 delay-100 leading-relaxed">
             {member.description}
           </p>
        </div>
      </div>
    </motion.div>
  );
};

export default CastCard;