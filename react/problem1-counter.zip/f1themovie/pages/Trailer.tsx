import React from 'react';
import PageTransition from '../components/PageTransition';

const Trailer: React.FC = () => {
  return (
    <PageTransition>
      <div className="min-h-screen bg-black flex items-center justify-center relative px-6">
        {/* Blurred BG */}
        <div className="absolute inset-0 z-0 overflow-hidden">
           <img src="https://picsum.photos/id/296/1920/1080" className="w-full h-full object-cover blur-3xl opacity-30" alt="Background" />
        </div>

        <div className="relative z-10 w-full max-w-5xl">
          <div className="text-center mb-10">
            <h2 className="text-f1-red text-sm font-bold uppercase tracking-[0.4em] mb-2">공식 예고편</h2>
            <h1 className="text-4xl md:text-6xl text-white font-black italic">액션을 확인하라</h1>
          </div>
          
          <div className="aspect-video w-full bg-black border border-zinc-800 shadow-[0_0_50px_rgba(220,0,0,0.2)] relative group">
            {/* Simulate Video Player with standard controls or iframe */}
            <iframe 
              width="100%" 
              height="100%" 
              src="https://www.youtube.com/embed/Sj4gI9c4e2k?si=123" 
              title="YouTube video player" 
              frameBorder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
              allowFullScreen
              className="w-full h-full"
            ></iframe>
          </div>

          <div className="mt-8 flex justify-center gap-8">
             <div className="text-center">
               <p className="text-white font-black text-2xl">2025. 08. 24</p>
               <p className="text-zinc-500 text-xs uppercase tracking-widest">전 세계 동시 개봉</p>
             </div>
             <div className="w-px bg-zinc-700 h-10"></div>
             <div className="text-center">
               <p className="text-white font-black text-2xl">IMAX</p>
               <p className="text-zinc-500 text-xs uppercase tracking-widest">독점 상영</p>
             </div>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default Trailer;