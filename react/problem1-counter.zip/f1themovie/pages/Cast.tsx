import React from 'react';
import PageTransition from '../components/PageTransition';
import CastCard from '../components/CastCard';
import { CastMember } from '../types';

const castData: CastMember[] = [
  {
    id: 1,
    name: "레오 로시",
    role: "루키",
    image: "https://picsum.photos/id/338/500/800",
    description: "나폴리의 거리에서 온 원석. 감정적으로 운전하며, 종종 엔지니어링의 한계를 넘어 차를 몰아붙인다."
  },
  {
    id: 2,
    name: "제임스 헌틀리",
    role: "베테랑",
    image: "https://picsum.photos/id/1005/500/800",
    description: "3회 월드 챔피언. 냉철하고 계산적이며, 자신의 왕좌를 지키기 위해서라면 무엇이든 할 준비가 되어 있다."
  },
  {
    id: 3,
    name: "엘레나 보스톡",
    role: "팀 감독",
    image: "https://picsum.photos/id/64/500/800",
    description: "패독의 철의 여인. 그녀는 무자비한 효율성으로 에고와 스폰서, 전략을 관리한다."
  },
  {
    id: 4,
    name: "켄지 사토",
    role: "수석 엔지니어",
    image: "https://picsum.photos/id/1012/500/800",
    description: "남들이 보지 못하는 공기의 흐름을 읽는 천재 공기역학자. 예산 제한에 맞서 혁신을 위해 싸운다."
  },
];

const Cast: React.FC = () => {
  return (
    <PageTransition>
      <div className="min-h-screen bg-black pt-20 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <h1 className="text-5xl md:text-8xl font-black text-white uppercase italic tracking-tighter mb-4">
              더 <span className="text-transparent bg-clip-text bg-gradient-to-r from-f1-red to-red-900">그리드</span>
            </h1>
            <p className="text-zinc-400 uppercase tracking-widest">전설과 도전자들을 만나보세요</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {castData.map((member) => (
              <CastCard key={member.id} member={member} />
            ))}
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default Cast;