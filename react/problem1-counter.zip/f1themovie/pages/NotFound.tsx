import React from 'react';
import { Link } from 'react-router-dom';
import { AlertTriangle } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="h-screen w-full bg-black flex flex-col items-center justify-center text-center px-4 relative">
       {/* Gravel Texture Overlay simulated with noise or just simple background */}
       <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)' opacity='1'/%3E%3C/svg%3E")` }}></div>

       <div className="relative z-10">
         <AlertTriangle size={80} className="text-f1-red mx-auto mb-6 animate-pulse" />
         <h1 className="text-8xl font-black italic text-white mb-2">DNF</h1>
         <h2 className="text-2xl text-zinc-400 uppercase tracking-widest mb-8">그래블 트랩에 빠졌습니다.</h2>
         <p className="text-zinc-500 mb-8 max-w-md mx-auto keep-all">찾으시는 페이지가 레이스에서 리타이어했습니다. 피트로 복귀하세요.</p>
         
         <Link to="/" className="inline-block px-8 py-3 border border-f1-red text-f1-red hover:bg-f1-red hover:text-white transition-all duration-300 font-bold uppercase tracking-wider">
           안전하게 복귀하기
         </Link>
       </div>
    </div>
  );
};

export default NotFound;