import React, { useState } from 'react';
import PageTransition from '../components/PageTransition';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

const images = [
  { id: 1, url: 'https://picsum.photos/id/366/1200/800', caption: '스타팅 그리드' },
  { id: 2, url: 'https://picsum.photos/id/445/1200/800', caption: '모나코의 비' },
  { id: 3, url: 'https://picsum.photos/id/1071/1200/800', caption: '핏 스탑의 혼돈' },
  { id: 4, url: 'https://picsum.photos/id/146/1200/800', caption: '엔지니어링 베이' },
  { id: 5, url: 'https://picsum.photos/id/231/1200/800', caption: '충돌 사고' },
  { id: 6, url: 'https://picsum.photos/id/111/1200/800', caption: '빅토리 랩' },
];

const Gallery: React.FC = () => {
  const [selectedId, setSelectedId] = useState<number | null>(null);

  return (
    <PageTransition>
      <div className="min-h-screen bg-zinc-950 pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-12 border-b border-zinc-800 pb-6">
             <h1 className="text-4xl md:text-6xl font-black uppercase text-white italic">비하인드 씬</h1>
             <span className="text-f1-red font-bold text-xl">0{images.length}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {images.map((img) => (
              <motion.div
                key={img.id}
                layoutId={`image-${img.id}`}
                onClick={() => setSelectedId(img.id)}
                className="relative group cursor-pointer aspect-video overflow-hidden border border-zinc-800"
                whileHover={{ scale: 1.02 }}
              >
                <img src={img.url} alt={img.caption} className="w-full h-full object-cover transition-all duration-500 group-hover:grayscale-0 grayscale opacity-80 group-hover:opacity-100" />
                <div className="absolute inset-0 bg-black/50 group-hover:bg-transparent transition-colors duration-300"></div>
                <div className="absolute bottom-4 left-4">
                  <p className="text-white font-bold uppercase tracking-wider text-sm translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    {img.caption}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          <AnimatePresence>
            {selectedId && (
              <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/95 backdrop-blur-xl p-4">
                <motion.button 
                  onClick={() => setSelectedId(null)}
                  className="absolute top-8 right-8 text-white hover:text-f1-red transition-colors"
                >
                  <X size={40} />
                </motion.button>

                {images.map((img) => (
                  img.id === selectedId && (
                    <motion.div 
                      layoutId={`image-${img.id}`}
                      key={img.id}
                      className="relative max-w-5xl w-full"
                    >
                      <img src={img.url} alt={img.caption} className="w-full h-auto max-h-[80vh] object-contain border border-zinc-800 shadow-2xl shadow-red-900/20" />
                      <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="mt-6 text-center"
                      >
                         <h3 className="text-2xl text-white font-black uppercase italic tracking-wider">{img.caption}</h3>
                      </motion.div>
                    </motion.div>
                  )
                ))}
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </PageTransition>
  );
};

export default Gallery;