import React from 'react';
import PageTransition from '../components/PageTransition';
import { motion } from 'framer-motion';

const About: React.FC = () => {
  return (
    <PageTransition>
      <div className="min-h-screen bg-black text-white relative">
        
        {/* Header Section */}
        <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
           <img 
            src="https://picsum.photos/id/191/1920/1080" 
            alt="Circuit" 
            className="absolute inset-0 w-full h-full object-cover opacity-40 grayscale"
           />
           <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/60 to-black"></div>
           
           <div className="relative z-10 text-center px-4">
             <motion.h1 
               initial={{ y: 50, opacity: 0 }}
               whileInView={{ y: 0, opacity: 1 }}
               className="text-5xl md:text-7xl font-black uppercase italic tracking-tighter mb-4"
             >
               속도를 향한 <span className="text-f1-red">갈망</span>
             </motion.h1>
             <p className="text-zinc-400 text-lg tracking-widest uppercase">시놉시스 & 비전</p>
           </div>
        </section>

        {/* Content Section */}
        <div className="max-w-4xl mx-auto px-6 py-20">
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="space-y-12"
          >
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="md:w-1/2">
                <h2 className="text-3xl font-bold uppercase mb-6 text-f1-red">스토리</h2>
                <p className="text-zinc-300 leading-8 text-lg mb-6 keep-all">
                  1000분의 1초가 전설을 정의하는 세계, 신인 드라이버(알렉스 머서 분)가 포뮬러 1의 치열한 정치적 전쟁터에 던져진다. 
                  챔피언이 치명적인 사고를 당하자, 팀은 미지의 신인에게 모든 것을 걸어야 하는 상황에 처한다.
                </p>
                <p className="text-zinc-300 leading-8 text-lg keep-all">
                  하지만 위험한 것은 속도뿐만이 아니다. 라이벌 관계, 기업 간의 스파이 전쟁, 그리고 5G의 중력을 견디는 육체적 고통이 모나코의 체커기가 휘날리기 전 팀을 벼랑 끝으로 몰아넣는다.
                </p>
              </div>
              <div className="md:w-1/2 relative">
                 <div className="absolute inset-0 border-2 border-f1-red transform translate-x-4 translate-y-4"></div>
                 <img src="https://picsum.photos/id/449/600/800" alt="Driver Helmet" className="relative z-10 grayscale hover:grayscale-0 transition-all duration-700" />
              </div>
            </div>

            <div className="h-px bg-zinc-800 my-12"></div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
               <div className="p-6 border border-zinc-800 hover:border-f1-red transition-colors duration-300">
                 <h3 className="text-4xl font-black text-white mb-2 italic">120<span className="text-lg text-f1-red not-italic ml-1">분</span></h3>
                 <p className="text-zinc-500 uppercase tracking-widest text-xs">러닝타임</p>
               </div>
               <div className="p-6 border border-zinc-800 hover:border-f1-red transition-colors duration-300">
                 <h3 className="text-4xl font-black text-white mb-2 italic">IMAX</h3>
                 <p className="text-zinc-500 uppercase tracking-widest text-xs">촬영</p>
               </div>
               <div className="p-6 border border-zinc-800 hover:border-f1-red transition-colors duration-300">
                 <h3 className="text-4xl font-black text-white mb-2 italic">DOLBY</h3>
                 <p className="text-zinc-500 uppercase tracking-widest text-xs">Atmos 사운드</p>
               </div>
            </div>

          </motion.div>
        </div>
      </div>
    </PageTransition>
  );
};

export default About;