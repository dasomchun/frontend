import React from 'react';
import PageTransition from '../components/PageTransition';
import { Send } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <PageTransition>
      <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center px-4 py-20 relative overflow-hidden">
        
        <div className="absolute top-0 right-0 w-96 h-96 bg-f1-red rounded-full mix-blend-multiply filter blur-[128px] opacity-20 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-900 rounded-full mix-blend-multiply filter blur-[128px] opacity-20"></div>

        <div className="w-full max-w-4xl bg-black/50 backdrop-blur-md border border-zinc-800 p-8 md:p-12 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            
            {/* Info */}
            <div>
              <h1 className="text-4xl font-black text-white italic uppercase mb-6">언론 및 <br /><span className="text-f1-red">문의</span></h1>
              <p className="text-zinc-400 mb-8 leading-relaxed keep-all">
                배급권, 프레스 키트 또는 출연진 및 제작진 인터뷰 요청은 제작 사무소로 문의해 주십시오.
              </p>
              
              <div className="space-y-4">
                <div>
                  <h3 className="text-white font-bold uppercase text-sm tracking-wider">제작 사무소</h3>
                  <p className="text-zinc-500">영국 실버스톤 서킷 123번지</p>
                </div>
                <div>
                  <h3 className="text-white font-bold uppercase text-sm tracking-wider">이메일</h3>
                  <p className="text-zinc-500">press@f1themovie.com</p>
                </div>
                <div>
                  <h3 className="text-white font-bold uppercase text-sm tracking-wider">사이트 제작</h3>
                  <p className="text-zinc-500">[본인 이름] 디자인</p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form className="space-y-6">
              <div>
                <label className="block text-xs uppercase tracking-widest text-zinc-500 mb-2">이름</label>
                <input type="text" className="w-full bg-zinc-900 border border-zinc-800 p-4 text-white focus:outline-none focus:border-f1-red transition-colors" placeholder="이름을 입력하세요" />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-zinc-500 mb-2">이메일</label>
                <input type="email" className="w-full bg-zinc-900 border border-zinc-800 p-4 text-white focus:outline-none focus:border-f1-red transition-colors" placeholder="이메일을 입력하세요" />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-zinc-500 mb-2">메시지</label>
                <textarea rows={4} className="w-full bg-zinc-900 border border-zinc-800 p-4 text-white focus:outline-none focus:border-f1-red transition-colors" placeholder="메시지를 입력하세요"></textarea>
              </div>
              <button className="w-full bg-f1-red text-white font-bold uppercase tracking-widest py-4 hover:bg-red-700 transition-colors flex items-center justify-center gap-2 group">
                메시지 보내기 <Send size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </PageTransition>
  );
};

export default Contact;