import React from 'react';
import { Link } from 'react-router-dom';
import { Play, ChevronRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Home: React.FC = () => {
  return (
    <div className="relative w-full h-screen overflow-hidden bg-black text-white">
      {/* Background Image (Simulating Video) */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/id/296/1920/1080" 
          alt="F1 Track" 
          className="w-full h-full object-cover opacity-60 scale-105 animate-[pulse_10s_ease-in-out_infinite]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-transparent opacity-80"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-center px-6 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <h2 className="text-f1-red font-bold tracking-[0.3em] text-sm md:text-lg uppercase mb-4">
            2025년 여름 대개봉
          </h2>
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black italic tracking-tighter leading-none mb-2">
            F1: THE
          </h1>
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-black italic tracking-tighter leading-none text-transparent bg-clip-text bg-gradient-to-r from-white to-zinc-500 mb-10">
            MOVIE
          </h1>
          
          <p className="max-w-md text-zinc-300 text-lg md:text-xl mb-12 leading-relaxed border-l-4 border-f1-red pl-6 keep-all">
            속도, 배신, 그리고 영광을 경험하라. 당신이 한 번도 본 적 없는 세상에서 가장 빠른 스포츠.
          </p>

          <div className="flex flex-col md:flex-row gap-6">
            <Link to="/trailer" className="group relative px-8 py-4 bg-f1-red text-white font-bold uppercase tracking-widest overflow-hidden text-center">
              <span className="relative z-10 flex items-center justify-center gap-3">
                예고편 보기 <Play size={20} fill="currentColor" />
              </span>
              <div className="absolute inset-0 bg-white transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300 origin-left"></div>
              <div className="absolute inset-0 opacity-0 group-hover:opacity-10 mix-blend-overlay transition-opacity duration-300 bg-black"></div>
              <span className="absolute inset-0 z-10 flex items-center justify-center gap-3 text-f1-red opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                예고편 보기 <Play size={20} fill="currentColor" />
              </span>
            </Link>
            
            <Link to="/about" className="group px-8 py-4 border border-white text-white font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all duration-300 flex items-center justify-center gap-2">
              사이트 입장 <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </motion.div>
      </div>

      {/* Decorative Bottom Bar */}
      <div className="absolute bottom-0 w-full h-24 bg-gradient-to-t from-black to-transparent z-10 flex items-end justify-center pb-8">
        <motion.div 
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ delay: 1, duration: 1 }}
           className="animate-bounce"
        >
          <span className="text-zinc-500 text-xs tracking-[0.3em] uppercase">스크롤하여 탐색</span>
        </motion.div>
      </div>
    </div>
  );
};

export default Home;