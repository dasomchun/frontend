export interface CastMember {
  id: number;
  name: string;
  role: string;
  image: string;
  description: string;
}

export interface GalleryImage {
  id: number;
  url: string;
  caption: string;
}
